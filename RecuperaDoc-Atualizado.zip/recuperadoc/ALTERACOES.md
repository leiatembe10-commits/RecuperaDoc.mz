# Alterações desta versão

## Corrigido
1. **Fuga de dados na pesquisa** – `/pesquisar` e `GET /matches/:id` já não devolvem o número completo nem o nome completo. Vêm mascarados (`12••••••9A`, `João M••• S•••`). O contacto só aparece depois de liberado.
2. **Pagamento ligado** – "Já transferi" chama `POST /matches/:id/pagar` com o método (M-Pesa/e-Mola) e a referência. A pesquisa devolve agora o `match_id` correto.
3. **Contacto chega ao utilizador** – depois de pagar, a página consulta o estado de 20 em 20 s e mostra o contacto real quando o admin desbloqueia. Há também o link `perdi.html?match=ID` para voltar mais tarde.
4. **Notificações preparadas** – ao registar um documento encontrado, quem está à espera recebe um SMS (só com link, sem dados do documento). O registo fica em `notificacoes`. **Falta ligar um fornecedor de SMS real** (ver `backend/src/services/sms.js`).
5. **Segurança** – XSS corrigido no `perdi.html` e no `admin.html`; a chave do admin fica em `sessionStorage`; comparação da chave em tempo constante; limite de pedidos ao admin; CORS já não é `*` por defeito; validação de telefone moçambicano estrita.
6. **Admin** – removida uma função duplicada que impedia o botão "Desbloquear" de funcionar; agora mostra quais pagamentos foram declarados pelos utilizadores.
7. **Base de dados** – nova coluna `pagamento_declarado` e índice único contra matches duplicados. Bases já existentes: correr `database/migracao-001.sql`.

## Ainda por fazer (precisa de ti)
- Escolher e ligar um fornecedor de SMS (credenciais tuas).
- WhatsApp Cloud API (fase 2).
- Confirmação automática de M-Pesa/e-Mola (hoje é manual, pelo admin).
- Testar tudo com PostgreSQL real: esta versão foi verificada só por leitura e por verificação de sintaxe, não foi executada contra uma base de dados.
- Trocar `ADMIN_SECRET` por uma chave forte e ativar HTTPS no deploy.


---

# Segunda atualização: confirmação de pagamento por número e código

## O que mudou
1. **Pagamento em dois passos.** Primeiro a pessoa escolhe M-Pesa ou e-Mola e escreve **o número de onde vai transferir** (`POST /matches/:id/iniciar-pagamento`). Só depois vê para onde pagar. Depois de transferir, escreve o **código da transação** (`POST /matches/:id/pagar`).
2. **Código único.** O mesmo código não pode ser usado em dois pedidos (índice único na base de dados).
3. **Limite de tentativas.** Máximo de 5 tentativas de confirmação por pedido.
4. **Admin vê tudo lado a lado**: número (com os últimos 4 dígitos em destaque), código, valor esperado (45 MT) e hora. Ao desbloquear, o painel pede para confirmar esses dados contra a mensagem que a pessoa recebeu no telemóvel.
5. **Só desbloqueia com pagamento declarado** (a API recusa se não houver número e código).
6. **Registo de quem aprovou.** O painel pede o nome de quem entra (ex.: Rafael) e guarda-o em `liberado_por`.
7. **Textos**: taxa não reembolsável e uso do número de quem paga, em `perdi.html` e `termos.html`.

## Bases de dados que já existem
Corre, por ordem, uma vez cada: `database/migracao-001.sql` (se ainda não correste) e `database/migracao-002.sql`.
Base nova: o `schema.sql` já inclui tudo.

## Regra para quem confirma (Rafael)
Só desbloquear quando a mensagem que **chegou ao teu telemóvel** tiver: o mesmo número, o mesmo código e 45 MT. Nunca confiar em prints enviados pela pessoa.

## Ainda por confirmar
- Se a mensagem de e-Mola / M-Pesa mostra o número de quem enviou (perguntar ao Rafael).
- Se transferir de uma rede para outra tem custo extra.
- A cláusula de "sem reembolso": pedir a um advogado que a reveja.
