-- Migração 002: correr UMA vez em bases de dados que já existem
-- (numa base nova, o schema.sql já inclui isto).
-- Pré-requisito: a migracao-001.sql já foi corrida.

ALTER TABLE matches ADD COLUMN IF NOT EXISTS pagamento_numero TEXT;
ALTER TABLE matches ADD COLUMN IF NOT EXISTS pagamento_codigo TEXT;
ALTER TABLE matches ADD COLUMN IF NOT EXISTS pagamento_declarado_em TIMESTAMPTZ;
ALTER TABLE matches ADD COLUMN IF NOT EXISTS pagamento_tentativas INT DEFAULT 0;
ALTER TABLE matches ADD COLUMN IF NOT EXISTS liberado_por TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS uq_match_codigo_pagamento
  ON matches (pagamento_codigo) WHERE pagamento_codigo IS NOT NULL;
