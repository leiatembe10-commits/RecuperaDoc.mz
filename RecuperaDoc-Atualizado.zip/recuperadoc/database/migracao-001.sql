-- Migração 001: correr UMA vez em bases de dados que já existem.
-- (Numa base nova, o schema.sql já inclui isto.)

ALTER TABLE matches
  ADD COLUMN IF NOT EXISTS pagamento_declarado BOOLEAN DEFAULT false;

-- Evita matches duplicados entre o mesmo documento encontrado e o mesmo pedido de perdido
CREATE UNIQUE INDEX IF NOT EXISTS uq_match_encontrado_perdido
  ON matches (documento_encontrado_id, documento_perdido_id)
  WHERE documento_perdido_id IS NOT NULL;
