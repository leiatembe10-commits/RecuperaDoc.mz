-- =====================================================
-- RecuperaDoc - Schema completo da Base de Dados
-- Desenvolvido por Feliciano Sarmento Matos
-- Domínio: recuperadoc.mz
-- =====================================================

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_trgm;        -- Para matching fuzzy de nomes
CREATE EXTENSION IF NOT EXISTS unaccent;      -- Remove acentos

-- =====================================================
-- 1. Tabela de documentos ENCONTRADOS (quem achou)
-- =====================================================
CREATE TABLE documentos_encontrados (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Dados do documento
    tipo            VARCHAR(30) NOT NULL,          -- bi, carta, passaporte, outro
    numero          TEXT NOT NULL,
    numero_limpo    TEXT GENERATED ALWAYS AS (
                      lower(regexp_replace(numero, '[^a-zA-Z0-9]', '', 'g'))
                    ) STORED,
    nome            TEXT NOT NULL,
    nome_normalizado TEXT GENERATED ALWAYS AS (
                      lower(unaccent(nome))
                    ) STORED,
    data_nascimento DATE,
    data_validade   DATE,
    cidade          TEXT,
    observacoes     TEXT,
    foto_url        TEXT,
    
    -- Quem encontrou
    contacto_finder TEXT NOT NULL,                 -- telefone/WhatsApp de quem achou
    nome_finder     TEXT,                          -- nome de quem registou (opcional)
    
    -- Controlo
    status          VARCHAR(20) DEFAULT 'ativo',   -- ativo, recuperado, expirado
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- 2. Tabela de documentos PERDIDOS (quem procura + notificação)
-- =====================================================
CREATE TABLE documentos_perdidos (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Dados do documento perdido
    tipo            VARCHAR(30) NOT NULL,
    numero          TEXT,
    numero_limpo    TEXT GENERATED ALWAYS AS (
                      lower(regexp_replace(coalesce(numero,''), '[^a-zA-Z0-9]', '', 'g'))
                    ) STORED,
    nome            TEXT NOT NULL,
    nome_normalizado TEXT GENERATED ALWAYS AS (
                      lower(unaccent(nome))
                    ) STORED,
    data_nascimento DATE,
    
    -- Contacto para notificação
    contacto        TEXT NOT NULL,                 -- telefone/WhatsApp de quem perdeu
    autoriza_sms    BOOLEAN DEFAULT true,
    autoriza_whatsapp BOOLEAN DEFAULT true,
    
    -- Controlo
    status          VARCHAR(20) DEFAULT 'à_espera', -- à_espera, notificado, recuperado, cancelado
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- 3. Tabela de MATCHES (correspondências)
-- =====================================================
CREATE TABLE matches (
    id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_encontrado_id UUID NOT NULL REFERENCES documentos_encontrados(id),
    documento_perdido_id    UUID REFERENCES documentos_perdidos(id),
    
    score                 DECIMAL(4,3),            -- 0.000 a 1.000 (similaridade)
    tipo_match            VARCHAR(20),             -- exato, alto, medio
    
    -- Pagamento
    pagamento_status      VARCHAR(20) DEFAULT 'pendente', -- pendente, pago, expirado
    pagamento_valor       DECIMAL(10,2) DEFAULT 45.00,
    pagamento_metodo      VARCHAR(20),             -- mpesa, emola
    pagamento_referencia  TEXT,
    pagamento_declarado   BOOLEAN DEFAULT false,   -- utilizador clicou "já transferi"
    pagamento_numero      TEXT,                    -- número de onde a pessoa diz que vai transferir
    pagamento_codigo      TEXT,                    -- código da transação (da mensagem de confirmação)
    pagamento_declarado_em TIMESTAMPTZ,
    pagamento_tentativas  INT DEFAULT 0,           -- limite de tentativas de confirmação
    pago_em               TIMESTAMPTZ,
    
    -- Contacto liberado?
    contacto_liberado     BOOLEAN DEFAULT false,
    liberado_em           TIMESTAMPTZ,
    liberado_por          TEXT,                    -- quem aprovou no painel admin
    
    created_at            TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- 4. Tabela de notificações enviadas
-- =====================================================
CREATE TABLE notificacoes (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    documento_perdido_id UUID REFERENCES documentos_perdidos(id),
    match_id        UUID REFERENCES matches(id),
    
    canal           VARCHAR(20) NOT NULL,          -- sms, whatsapp
    destino         TEXT NOT NULL,
    mensagem        TEXT,
    status          VARCHAR(20) DEFAULT 'pendente', -- pendente, enviado, falhou
    enviado_em      TIMESTAMPTZ,
    erro            TEXT,
    
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- ÍNDICES FORTES (essenciais para performance)
-- =====================================================

-- Documentos encontrados
CREATE INDEX idx_enc_numero_limpo ON documentos_encontrados (numero_limpo);
CREATE INDEX idx_enc_nome_trgm ON documentos_encontrados USING GIN (nome_normalizado gin_trgm_ops);
CREATE INDEX idx_enc_tipo_numero ON documentos_encontrados (tipo, numero_limpo);
CREATE INDEX idx_enc_status ON documentos_encontrados (status) WHERE status = 'ativo';
CREATE INDEX idx_enc_created ON documentos_encontrados (created_at DESC);

-- Documentos perdidos
CREATE INDEX idx_perd_numero_limpo ON documentos_perdidos (numero_limpo);
CREATE INDEX idx_perd_nome_trgm ON documentos_perdidos USING GIN (nome_normalizado gin_trgm_ops);
CREATE INDEX idx_perd_status ON documentos_perdidos (status) WHERE status = 'à_espera';
CREATE INDEX idx_perd_contacto ON documentos_perdidos (contacto);

-- Matches
CREATE INDEX idx_match_encontrado ON matches (documento_encontrado_id);
CREATE INDEX idx_match_perdido ON matches (documento_perdido_id);
CREATE INDEX idx_match_pagamento ON matches (pagamento_status);
CREATE UNIQUE INDEX uq_match_encontrado_perdido ON matches (documento_encontrado_id, documento_perdido_id) WHERE documento_perdido_id IS NOT NULL;
-- Um código de transação só pode ser usado uma vez
CREATE UNIQUE INDEX uq_match_codigo_pagamento ON matches (pagamento_codigo) WHERE pagamento_codigo IS NOT NULL;

-- =====================================================
-- FUNÇÃO DE MATCHING (exemplo de lógica segura)
-- =====================================================
CREATE OR REPLACE FUNCTION procurar_correspondencias(
    p_tipo TEXT,
    p_numero TEXT,
    p_nome TEXT,
    p_data_nascimento DATE DEFAULT NULL
)
RETURNS TABLE (
    id UUID,
    tipo VARCHAR,
    numero TEXT,
    nome TEXT,
    cidade TEXT,
    score DECIMAL,
    tipo_match TEXT
) AS $$
DECLARE
    v_numero_limpo TEXT;
    v_nome_norm TEXT;
BEGIN
    v_numero_limpo := lower(regexp_replace(coalesce(p_numero,''), '[^a-zA-Z0-9]', '', 'g'));
    v_nome_norm := lower(unaccent(p_nome));

    RETURN QUERY
    SELECT 
        e.id,
        e.tipo,
        e.numero,
        e.nome,
        e.cidade,
        GREATEST(
            similarity(e.nome_normalizado, v_nome_norm),
            CASE WHEN e.numero_limpo = v_numero_limpo THEN 1.0 ELSE 0.0 END
        )::DECIMAL(4,3) AS score,
        CASE 
            WHEN e.numero_limpo = v_numero_limpo AND similarity(e.nome_normalizado, v_nome_norm) > 0.7 THEN 'exato'
            WHEN e.numero_limpo = v_numero_limpo OR similarity(e.nome_normalizado, v_nome_norm) > 0.75 THEN 'alto'
            ELSE 'medio'
        END AS tipo_match
    FROM documentos_encontrados e
    WHERE e.status = 'ativo'
      AND e.tipo = p_tipo
      AND (
            e.numero_limpo = v_numero_limpo
         OR similarity(e.nome_normalizado, v_nome_norm) > 0.55
      )
    ORDER BY score DESC
    LIMIT 5;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- COMENTÁRIOS
-- =====================================================
COMMENT ON TABLE documentos_encontrados IS 'Documentos registados por quem encontrou';
COMMENT ON TABLE documentos_perdidos IS 'Pedidos de quem perdeu + contacto para notificação';
COMMENT ON TABLE matches IS 'Correspondências entre encontrado e perdido + controlo de pagamento';
COMMENT ON TABLE notificacoes IS 'Histórico de SMS/WhatsApp enviados';
