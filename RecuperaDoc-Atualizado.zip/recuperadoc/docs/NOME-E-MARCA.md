# Nome e Marca – RecuperaDoc

**Grupo / Empresa:** F.S.Matusse  
**Nome de apresentação:** Sr. Visionário Matusse

---

## Como aparece no projeto

| Local                        | Texto usado                              |
|-----------------------------|------------------------------------------|
| Rodapé de todas as páginas  | **F.S.Matusse · Sr. Visionário Matusse** |
| Meta description            | F.S.Matusse · Sr. Visionário Matusse     |
| Termos de Uso               | F.S.Matusse · Sr. Visionário Matusse     |
| Documentação                | F.S.Matusse · Sr. Visionário Matusse     |

---

## Resumo

- **Marca / Grupo:** F.S.Matusse
- **Nome público:** Sr. Visionário Matusse

Esta é a forma oficial usada em todo o protótipo.
