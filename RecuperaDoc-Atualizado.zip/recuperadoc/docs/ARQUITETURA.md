# RecuperaDoc – Arquitetura Técnica

**Domínio:** recuperadoc.mz  
**Desenvolvedor:** Sr. Visionário Matusse  
**Data:** 2026

---

## 1. Visão Geral

O RecuperaDoc é uma plataforma web (mobile-first) que liga pessoas que perderam documentos de identificação a pessoas que os encontraram.

### Fluxo principal

```
1. Quem encontra → Regista documento + contacto
2. Quem perdeu  → Pesquisa
   ├─ Encontra possível match → Paga 45 MT → Recebe contacto
   └─ Não encontra → Deixa contacto → Fica à espera de notificação
3. Sistema detecta match posterior → Envia SMS/WhatsApp
4. Dono paga → Contacto é desbloqueado
5. Encontro presencial + recompensa (fora da plataforma)
```

---

## 2. Stack Recomendada

| Camada              | Tecnologia recomendada          | Alternativa          |
|---------------------|---------------------------------|----------------------|
| Frontend            | HTML/CSS/JS (atual) ou Next.js  | React / Vue          |
| Backend             | Node.js (Express/Fastify) ou Laravel | Python (FastAPI) |
| Base de Dados       | **PostgreSQL**                  | MySQL (menos ideal)  |
| Indexação / Search  | pg_trgm + B-tree                | Elasticsearch (overkill) |
| Notificações        | SMS (fase 1) + WhatsApp Cloud API | Twilio / 360dialog |
| Pagamentos          | Manual (M-Pesa / e-Mola) → depois API | —               |
| Hospedagem          | VPS (DigitalOcean, Contabo) ou Railway | Vercel + Supabase |
| Domínio             | recuperadoc.mz                  | —                    |

---

## 3. Base de Dados (PostgreSQL)

Ver ficheiro: `database/schema.sql`

### Tabelas principais

- `documentos_encontrados` → quem achou
- `documentos_perdidos` → quem perdeu + contacto para notificação
- `matches` → correspondências + controlo de pagamento
- `notificacoes` → histórico de SMS/WhatsApp

### Índices críticos

- B-tree no número do documento (limpo)
- GIN + pg_trgm no nome (tolerante a erros de escrita)
- Índices parciais por status

### Matching seguro

1. Match exato de número + nome → score alto
2. Similaridade de nome (trigram) > 0.70 → possível match
3. Sempre mostrar mensagem de “possível correspondência” (nunca garantir 100%)

---

## 4. Notificações

### Fase 1 (recomendada para lançar rápido)
- SMS via gateway local (Moçambique)
- Custo baixo e simples

### Fase 2
- WhatsApp Cloud API (Meta)
- Template tipo Utility:
  > “Olá! Alguém registou um documento que pode corresponder aos dados que indicou no RecuperaDoc. Aceda a recuperadoc.mz para ver os detalhes.”

### Preço aproximado (Moçambique 2026)
- Utility: ~$0.004 por mensagem
- Muito acessível

---

## 5. Pagamento (45 MT)

### Atual (protótipo)
- Mostra números M-Pesa e e-Mola
- Utilizador transfere e clica “Já transferi”
- Confirmação manual no início

### Evolução futura
- Integração com API M-Pesa / e-Mola (quando disponível)
- Confirmação automática via webhook

**Números atuais:**
- M-Pesa: 84 146 6870
- e-Mola: 86 608 2723

---

## 6. Segurança e Anti-Burla

- Nunca dizer “O seu documento foi encontrado” → dizer “Possível correspondência”
- Contacto do finder só é liberado depois do pagamento
- Avisos claros de local público e confirmação de identidade
- Limitação de pesquisas por IP/telefone (anti-spam)
- Logs de todas as ações importantes

---

## 7. Painel de Administração (futuro)

Funcionalidades mínimas:
- Ver documentos registados
- Ver matches pendentes
- Confirmar pagamentos manualmente
- Ver notificações enviadas
- Estatísticas básicas

---

## 8. Próximos Passos Reais

1. Registar domínio **recuperadoc.mz**
2. Escolher hospedagem (VPS ou Railway/Supabase)
3. Implementar backend + PostgreSQL
4. Ligar SMS (fase 1)
5. Testar com 20–50 documentos reais
6. Depois adicionar WhatsApp Cloud API
7. Criar painel admin simples

---

## 9. Estrutura de pastas atual

```
recuperadoc/
├── index.html
├── encontrei.html
├── perdi.html
├── sobre.html
├── termos.html
├── css/
├── js/
├── database/
│   └── schema.sql          ← Schema completo
├── docs/
│   └── ARQUITETURA.md      ← Este ficheiro
└── backend-exemplo/        ← Exemplos futuros
```
