# Lista de Tarefas para o Programador – RecuperaDoc

**Projeto:** RecuperaDoc (recuperadoc.mz)  
**Fundador / Desenvolvedor: F.S.Matusse · Sr. Visionário Matusse
**Objetivo:** Colocar a plataforma no ar de forma funcional e segura.

---

## Fase 1 – Fundação (Prioridade Máxima)

### 1. Domínio e Hospedagem
- [ ] Registar o domínio **recuperadoc.mz**
- [ ] Escolher hospedagem (recomendado: Railway, DigitalOcean ou Contabo)
- [ ] Configurar HTTPS (SSL)

### 2. Base de Dados
- [ ] Criar base de dados PostgreSQL
- [ ] Executar o ficheiro `database/schema.sql`
- [ ] Testar os índices e a função de matching

### 3. Backend
- [ ] Criar API (Node.js + Express/Fastify ou Laravel)
- [ ] Endpoints principais:
  - POST /encontrados → registar documento encontrado
  - POST /perdidos → registar pesquisa / pedido de notificação
  - GET /pesquisar → procurar correspondências
  - POST /matches/:id/pagar → marcar pagamento
  - POST /matches/:id/desbloquear → liberar contacto
- [ ] Proteção básica (rate limit, validação de dados)

### 4. Frontend
- [ ] Ligar os formulários atuais à API real
- [ ] Manter a linguagem segura (“possível correspondência”)
- [ ] Manter o fluxo de deixar contacto quando não encontra

---

## Fase 2 – Notificações e Pagamento

### 5. Notificações
- [ ] Integrar SMS (gateway local de Moçambique) – Fase 1
- [ ] Preparar WhatsApp Cloud API (Meta) – Fase 2
- [ ] Criar template de mensagem Utility para aprovação da Meta

### 6. Pagamento
- [ ] Manter confirmação manual no início (mais seguro)
- [ ] Criar painel simples para o dono confirmar “pagamento recebido”
- [ ] (Futuro) Integrar API M-Pesa / e-Mola se disponível

---

## Fase 3 – Administração e Segurança

### 7. Painel Admin
- [ ] Login seguro para o fundador
- [ ] Ver documentos registados
- [ ] Ver matches pendentes
- [ ] Confirmar pagamentos
- [ ] Ver histórico de notificações
- [ ] Estatísticas básicas

### 8. Segurança
- [ ] Rate limiting (evitar spam de pesquisas)
- [ ] Validação forte de números de telefone
- [ ] Logs de ações importantes
- [ ] Proteção contra dados falsos em massa

---

## Ordem recomendada de execução

1. Domínio + Hospedagem
2. Base de dados (schema.sql)
3. Backend básico (registar + pesquisar)
4. Ligar o frontend
5. Notificações SMS
6. Painel admin simples
7. WhatsApp (depois)

---

## Notas importantes

- Nunca dizer “O seu documento foi encontrado” → sempre “possível correspondência”
- Contacto do finder só é liberado depois da confirmação de pagamento
- Manter os números de pagamento:
  - M-Pesa: 84 146 6870
  - e-Mola: 86 608 2723
- Taxa: 45 MT
