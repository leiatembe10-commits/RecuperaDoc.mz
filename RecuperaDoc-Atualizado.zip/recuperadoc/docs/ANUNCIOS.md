# Textos de Anúncios – RecuperaDoc

**Para usar no Facebook, Instagram, WhatsApp Status e grupos**

---

## 1. Anúncio principal (curto e forte)

**Perdeu o BI, a Carta ou o Passaporte?**

Alguém pode ter encontrado.

Procure agora em:
👉 recuperadoc.mz

Se não encontrar, deixe o seu contacto.
Avisamos quando aparecer.

Simples. Rápido. Seguro.

---

## 2. Anúncio para quem encontrou documento

**Encontrou um documento de alguém?**

BI, Carta de Condução, Passaporte...

Registe em recuperadoc.mz
O dono pode ser notificado e vai recompensá-lo na entrega.

Ajude alguém hoje.
👉 recuperadoc.mz

---

## 3. Anúncio com foco em notificação

**Perdeu o documento e ainda não apareceu?**

No RecuperaDoc pode deixar o seu número.
Assim que alguém registar um documento parecido, 
recebe aviso por SMS ou WhatsApp.

Aceda agora:
👉 recuperadoc.mz

---

## 4. Versão para WhatsApp Status / Grupos

Perdeu documento? 📄
Ou encontrou o de alguém?

Usa o RecuperaDoc:
recuperadoc.mz

- Quem encontrou: regista
- Quem perdeu: procura ou deixa contacto
- Se bater: o dono é avisado

Simples e feito para o telemóvel.

---

## 5. Versão mais formal

RecuperaDoc é uma plataforma digital que ajuda pessoas a recuperar documentos de identificação perdidos.

Quem encontra regista o documento.
Quem perde pode procurar ou deixar o contacto para ser notificado.

Taxa de serviço: 45 MT (apenas para desbloquear o contacto).

Aceda em: recuperadoc.mz

---

## 6. Hashtags sugeridas

#RecuperaDoc #DocumentoPerdido #BI #CartaDeConducao #Maputo #Moçambique #AjudaComunidade

---

## Dicas de publicação

- Publicar à noite e de manhã (quando as pessoas mais perdem documentos)
- Usar nos grupos de bairros, motoqueiros, motoristas e mercados
- Pedir às pessoas para partilharem
