# Guia de Deploy – RecuperaDoc

**Objetivo:** Colocar a plataforma no ar de forma funcional.

---

## Opção recomendada: Railway (mais fácil e barata)

### 1. Criar conta
- Vai a [railway.app](https://railway.app) e cria conta (podes usar GitHub)

### 2. Criar projeto PostgreSQL
1. New Project → Provision PostgreSQL
2. Copia a `DATABASE_URL` (vai aparecer nas Variables)

### 3. Correr o schema
1. No serviço PostgreSQL → clique em "Query" ou use um cliente (DBeaver, TablePlus, psql)
2. Cola todo o conteúdo de `database/schema.sql` e executa

### 4. Deploy da API
1. New → GitHub Repo (ou Upload)
2. Ou usa o botão "Deploy from GitHub" apontando para a pasta `backend`
3. Adiciona as variáveis de ambiente:
   ```
   DATABASE_URL=... (a que copiaste)
   PORT=3000
   NODE_ENV=production
   ADMIN_SECRET=uma-chave-muito-forte-e-secreta-2026
   CORS_ORIGIN=https://recuperadoc.mz,https://www.recuperadoc.mz
   ```
4. Railway vai detetar o `package.json` e fazer deploy automático
5. Copia o domínio público da API (ex: `recuperadoc-api.up.railway.app`)

### 5. Frontend
Podes hospedar o frontend de várias formas:

**Opção A – Netlify / Vercel (gratuito e fácil)**
1. Faz upload da pasta `recuperadoc` (sem a pasta backend)
2. Em `js/config.js` muda o `API_BASE_URL` para o URL da tua API no Railway

**Opção B – Mesmo Railway (servir estático)**
Ou usa qualquer hospedagem de ficheiros estáticos.

### 6. Domínio recuperadoc.mz
1. Compra o domínio (se ainda não tiveres)
2. No painel do domínio, aponta:
   - `@` e `www` → Netlify/Vercel
   - `api` → Railway (CNAME)

---

## Alternativa: DigitalOcean / Contabo (VPS)

1. Cria um droplet Ubuntu
2. Instala Node.js + PostgreSQL
3. Corre o schema.sql
4. Usa PM2 para manter a API a correr
5. Nginx como reverse proxy + SSL (Certbot)

---

## Checklist final antes de lançar

- [ ] Schema.sql corrido com sucesso
- [ ] API a responder em `/`
- [ ] Frontend a chamar a API correta (`js/config.js`)
- [ ] Testar registo de documento encontrado
- [ ] Testar pesquisa
- [ ] Testar deixar contacto
- [ ] Testar painel admin (`/admin.html`)
- [ ] HTTPS ativo
- [ ] Números M-Pesa e e-Mola corretos

---

## Suporte

Se tiveres problemas no deploy, manda print do erro e eu ajudo a resolver.
