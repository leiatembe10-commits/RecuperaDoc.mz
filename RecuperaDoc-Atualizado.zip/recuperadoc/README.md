# RecuperaDoc – recuperadoc.mz

**Fundador e Desenvolvedor: **F.S.Matusse** · Sr. Visionário Matusse

Plataforma para recuperar documentos de identificação perdidos (BI, Carta de Condução, Passaporte, etc.).

---

## O que está incluído neste pacote

### 1. Website (Protótipo funcional)
- index.html, encontrei.html, perdi.html, sobre.html, termos.html
- Design mobile-first
- Fluxo completo de pesquisa + notificação + pagamento (45 MT)
- Linguagem segura (anti-burla)

### 2. Base de Dados
- `database/schema.sql` → Schema completo com índices fortes

### 3. Documentação
- `docs/ARQUITETURA.md` → Arquitetura técnica
- `docs/TAREFAS-PROGRAMADOR.md` → Lista de tarefas para o programador
- `docs/ANUNCIOS.md` → Textos de anúncios prontos
- `docs/NOME-E-MARCA.md` → Sugestões de como o nome deve aparecer

---

## Números de pagamento
- **M-Pesa:** 84 146 6870
- **e-Mola:** 86 608 2723
- **Taxa:** 45 MT

---

## Como testar o protótipo
1. Abra `index.html`
2. Em “Perdi um documento”:
   - Dados normais → “Nenhuma correspondência” + deixar contacto
   - Número com `teste123` ou nome com `exemplo` → possível correspondência

---

## Próximos passos reais
1. Registar domínio recuperadoc.mz
2. Contratar/hospedar + programador
3. Seguir a lista em `docs/TAREFAS-PROGRAMADOR.md`
4. Começar a divulgar com os textos de `docs/ANUNCIOS.md`

---

© 2026 RecuperaDoc  
Criado por **F.S.Matusse** · Sr. Visionário Matusse
