# Como correr o RecuperaDoc localmente

## Pré-requisitos
- Node.js 18+ instalado
- PostgreSQL 14+ instalado e a correr

---

## 1. Preparar a Base de Dados

```bash
# Criar a base de dados
createdb recuperadoc

# Correr o schema
psql -d recuperadoc -f database/schema.sql
```

Se usares Docker para PostgreSQL:
```bash
docker run --name recuperadoc-db -e POSTGRES_PASSWORD=senha123 -e POSTGRES_DB=recuperadoc -p 5432:5432 -d postgres:16
# Depois corre o schema
psql -h localhost -U postgres -d recuperadoc -f database/schema.sql
```

**Já tens uma base de dados criada com o schema antigo?** Corre também, uma vez:
```bash
psql -d recuperadoc -f database/migracao-001.sql
psql -d recuperadoc -f database/migracao-002.sql
```

---

## 2. Configurar a API

```bash
cd backend
cp .env.example .env
```

Edita o ficheiro `.env`:
```
DATABASE_URL=postgresql://postgres:senha123@localhost:5432/recuperadoc
PORT=3000
NODE_ENV=development
ADMIN_SECRET=chave-secreta-muito-forte-2026
CORS_ORIGIN=http://localhost:5500,http://127.0.0.1:5500
```

Instalar dependências (a pasta `node_modules` não vem no zip):
```bash
npm install
```

Correr a API:
```bash
npm run dev
```

Deves ver:
```
🚀 RecuperaDoc API a correr na porta 3000
✅ Ligado à base de dados PostgreSQL
```

---

## 3. Correr o Frontend

Abre outro terminal na pasta raiz do projeto e usa um servidor estático:

```bash
# Opção 1 - com npx (recomendado)
npx serve -l 5500 .

# Opção 2 - com Python
python3 -m http.server 5500
```

Depois abre no browser:
- http://localhost:5500
- http://localhost:5500/admin.html  ← Painel admin

(A API usa a porta 3000; o site usa a 5500.)

---

## 4. Testar o fluxo completo

1. Vai a **Encontrei um documento** e regista um documento de teste
2. Vai a **Perdi um documento** e pesquisa com os mesmos dados
3. Deve aparecer "Possível correspondência" (com número e nome parcialmente escondidos)
4. Escolhe M-Pesa/e-Mola, escreve o número de onde vais "transferir", depois o código da transação (inventa um, ex.: TESTE12345) e clica "Já transferi"
5. Entra no painel admin (`admin.html`) com a chave secreta e desbloqueia o contacto
6. A página do utilizador mostra o contacto sozinha, em até 20 segundos

---

## Problemas comuns

**Erro de conexão à base de dados**
→ Verifica se o PostgreSQL está a correr e se a `DATABASE_URL` está correta.

**CORS error no browser**
→ Confirma que o endereço do site (ex.: `http://localhost:5500`) está em `CORS_ORIGIN` no `.env`.

**Função `procurar_correspondencias` não existe**
→ Garante que correste o `schema.sql` completo.
