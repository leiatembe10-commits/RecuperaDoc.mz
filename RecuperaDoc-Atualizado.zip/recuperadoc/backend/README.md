# RecuperaDoc API – Backend

API oficial do **RecuperaDoc** (recuperadoc.mz)

Desenvolvido para: **F.S.Matusse · Sr. Visionário Matusse**

---

## Endpoints disponíveis

| Método | Endpoint                    | Descrição                              |
|--------|-----------------------------|----------------------------------------|
| POST   | `/encontrados`              | Registar documento encontrado          |
| POST   | `/perdidos`                 | Registar pedido de notificação         |
| GET    | `/pesquisar`                | Pesquisar possíveis correspondências   |
| POST   | `/matches/:id/pagar`        | Utilizador indica que já pagou         |
| POST   | `/matches/:id/desbloquear`  | Admin desbloqueia contacto             |
| GET    | `/matches/:id`              | Ver estado de um match                 |

---

## 1. Configurar a Base de Dados

### Opção A – Local (desenvolvimento)
```bash
# Criar base de dados
createdb recuperadoc

# Correr o schema
psql -d recuperadoc -f ../database/schema.sql
```

### Opção B – Railway / Render / DigitalOcean / Supabase
1. Cria um serviço PostgreSQL
2. Copia a `DATABASE_URL`
3. Corre o ficheiro `database/schema.sql` (pela interface SQL ou `psql`)

---

## 2. Configurar a API

```bash
cd backend
cp .env.example .env
# Edita o .env e coloca a DATABASE_URL correta
```

Instalar dependências:
```bash
npm install
```

Correr em desenvolvimento:
```bash
npm run dev
```

Correr em produção:
```bash
npm start
```

---

## 3. Exemplos de uso

### Registar documento encontrado
```bash
curl -X POST http://localhost:3000/encontrados \
  -H "Content-Type: application/json" \
  -d '{
    "tipo": "bi",
    "numero": "123456789A",
    "nome": "João Manuel da Silva",
    "cidade": "Maputo",
    "contacto_finder": "841234567",
    "nome_finder": "Carlos"
  }'
```

### Pesquisar
```bash
curl "http://localhost:3000/pesquisar?tipo=bi&numero=123456789A&nome=João%20Manuel%20da%20Silva"
```

### Registar pedido de notificação
```bash
curl -X POST http://localhost:3000/perdidos \
  -H "Content-Type: application/json" \
  -d '{
    "tipo": "bi",
    "numero": "123456789A",
    "nome": "João Manuel da Silva",
    "contacto": "847654321"
  }'
```

### Desbloquear contacto (Admin)
```bash
curl -X POST http://localhost:3000/matches/UUID-DO-MATCH/desbloquear \
  -H "Content-Type: application/json" \
  -H "x-admin-secret: a-tua-chave-secreta" \
  -d '{}'
```

---

## 4. Próximos passos recomendados

1. Ligar o frontend (HTML atual) a estes endpoints
2. Criar painel admin simples para confirmar pagamentos
3. Integrar SMS (gateway local de Moçambique)
4. Deploy da API + frontend

---

## Notas importantes

- O contacto do finder **só é devolvido** depois de `contacto_liberado = true`
- Sempre usar linguagem de “possível correspondência”
- Rate limiting já está ativo (anti-spam)
- Validação de números moçambicanos incluída
