const db = require('../db');
const { enviarSMS } = require('./sms');

const PUBLIC_URL = (process.env.PUBLIC_URL || 'https://recuperadoc.mz').replace(/\/$/, '');

/**
 * Avisa quem perdeu um documento que há uma possível correspondência.
 * A mensagem NÃO inclui dados do documento nem contacto de ninguém,
 * só um link para ver os detalhes no site.
 */
async function notificarMatch({ matchId, perdidoId, destino, autorizaSms }) {
  if (!autorizaSms) return;

  const mensagem =
    'RecuperaDoc: pode haver uma possível correspondência com o documento que procura. ' +
    `Veja os detalhes em ${PUBLIC_URL}/perdi.html?match=${matchId}`;

  const registo = await db.query(
    `INSERT INTO notificacoes (documento_perdido_id, match_id, canal, destino, mensagem, status)
     VALUES ($1, $2, 'sms', $3, $4, 'pendente')
     RETURNING id`,
    [perdidoId, matchId, destino, mensagem]
  );
  const notifId = registo.rows[0].id;

  const resultado = await enviarSMS(destino, mensagem);

  if (resultado.ok) {
    await db.query(
      `UPDATE notificacoes SET status = 'enviado', enviado_em = NOW() WHERE id = $1`,
      [notifId]
    );
  } else if (resultado.naoConfigurado) {
    // Fica 'pendente' para o admin ver que falta enviar
    await db.query(`UPDATE notificacoes SET erro = $2 WHERE id = $1`, [notifId, resultado.erro]);
  } else {
    await db.query(
      `UPDATE notificacoes SET status = 'falhou', erro = $2 WHERE id = $1`,
      [notifId, resultado.erro]
    );
  }
}

module.exports = { notificarMatch };
