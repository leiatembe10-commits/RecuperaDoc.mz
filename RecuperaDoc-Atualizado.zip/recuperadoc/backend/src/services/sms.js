/**
 * Envio de SMS.
 *
 * IMPORTANTE: não existe aqui nenhum fornecedor real ligado. Precisas de:
 *   1. Escolher um gateway de SMS que envie para Moçambique (Vodacom, Movitel, tmcel)
 *   2. Ter conta e credenciais nesse fornecedor
 *   3. Ajustar a função enviarViaHttp() abaixo ao formato da API desse fornecedor
 *
 * Enquanto SMS_PROVIDER não estiver definido no .env, nada é enviado:
 * a notificação fica registada na tabela `notificacoes` com status 'pendente'
 * e o painel admin pode ver que precisa de ser enviada.
 */

async function enviarViaHttp(destino, mensagem) {
  const url = process.env.SMS_API_URL;
  const key = process.env.SMS_API_KEY;
  if (!url || !key) {
    return { ok: false, erro: 'SMS_API_URL / SMS_API_KEY em falta no .env' };
  }

  // TODO: ajustar este corpo e os headers à documentação do teu fornecedor.
  const resposta = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${key}`
    },
    body: JSON.stringify({
      to: destino,
      from: process.env.SMS_SENDER || 'RecuperaDoc',
      message: mensagem
    })
  });

  if (!resposta.ok) {
    return { ok: false, erro: `Fornecedor respondeu ${resposta.status}` };
  }
  return { ok: true };
}

async function enviarSMS(destino, mensagem) {
  const provider = (process.env.SMS_PROVIDER || '').toLowerCase();

  if (!provider) {
    return { ok: false, naoConfigurado: true, erro: 'SMS_PROVIDER não configurado' };
  }

  try {
    if (provider === 'http') return await enviarViaHttp(destino, mensagem);
    return { ok: false, erro: `Fornecedor desconhecido: ${provider}` };
  } catch (err) {
    return { ok: false, erro: err.message };
  }
}

module.exports = { enviarSMS };
