const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// Testar conexão ao iniciar
pool.on('connect', () => {
  console.log('✅ Ligado à base de dados PostgreSQL');
});

pool.on('error', (err) => {
  console.error('❌ Erro na base de dados:', err.message);
});

module.exports = {
  query: (text, params) => pool.query(text, params),
  pool
};
