const express = require('express');
const router = express.Router();
const db = require('../db');
const { notificarMatch } = require('../services/notificar');
const { validateDocumento, cleanPhone } = require('../middleware/validate');

/**
 * POST /encontrados
 * Registar um documento encontrado
 */
router.post('/', async (req, res) => {
  try {
    const {
      tipo,
      numero,
      nome,
      data_nascimento,
      data_validade,
      cidade,
      observacoes,
      contacto_finder,
      nome_finder,
      foto_url
    } = req.body;

    // Validação
    const errors = validateDocumento({
      tipo,
      nome,
      contacto: contacto_finder
    });

    if (!numero || numero.trim().length < 3) {
      errors.push('Número do documento é obrigatório');
    }

    if (!cidade || cidade.trim().length < 2) {
      errors.push('Cidade/bairro onde encontrou é obrigatória');
    }

    if (errors.length > 0) {
      return res.status(400).json({
        success: false,
        errors
      });
    }

    const contactoLimpo = cleanPhone(contacto_finder);

    const result = await db.query(
      `INSERT INTO documentos_encontrados 
        (tipo, numero, nome, data_nascimento, data_validade, cidade, observacoes, contacto_finder, nome_finder, foto_url)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       RETURNING id, tipo, numero, nome, cidade, status, created_at`,
      [
        tipo,
        numero.trim(),
        nome.trim(),
        data_nascimento || null,
        data_validade || null,
        cidade.trim(),
        observacoes || null,
        contactoLimpo,
        nome_finder || null,
        foto_url || null
      ]
    );

    const documento = result.rows[0];

    // Tentar encontrar matches com documentos perdidos à espera
    // e notifica-os (SMS) se houver fornecedor configurado
    await criarMatchesSeExistirem(documento.id);

    res.status(201).json({
      success: true,
      message: 'Documento registado com sucesso. Obrigado por ajudar!',
      data: {
        id: documento.id,
        tipo: documento.tipo,
        numero: documento.numero,
        nome: documento.nome,
        cidade: documento.cidade,
        status: documento.status,
        created_at: documento.created_at
      }
    });

  } catch (error) {
    console.error('Erro ao registar documento encontrado:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno ao registar o documento'
    });
  }
});

/**
 * Função auxiliar: procura possíveis matches com documentos perdidos
 * e cria registos na tabela matches
 */
async function criarMatchesSeExistirem(documentoEncontradoId) {
  try {
    // Buscar o documento encontrado
    const doc = await db.query(
      'SELECT * FROM documentos_encontrados WHERE id = $1',
      [documentoEncontradoId]
    );

    if (doc.rows.length === 0) return;

    const encontrado = doc.rows[0];

    // Procurar documentos perdidos semelhantes que estão à espera
    const perdidos = await db.query(
      `SELECT id, nome, numero, contacto, autoriza_sms
       FROM documentos_perdidos
       WHERE status = 'à_espera'
         AND tipo = $1
         AND (
           (numero_limpo IS NOT NULL AND numero_limpo = $2)
           OR similarity(nome_normalizado, $3) > 0.60
         )
       LIMIT 10`,
      [
        encontrado.tipo,
        encontrado.numero_limpo,
        encontrado.nome_normalizado
      ]
    );

    for (const perdido of perdidos.rows) {
      // Calcular score
      const scoreResult = await db.query(
        `SELECT 
           GREATEST(
             similarity($1, $2),
             CASE WHEN $3 = $4 THEN 1.0 ELSE 0.0 END
           )::DECIMAL(4,3) AS score`,
        [
          encontrado.nome_normalizado,
          perdido.nome ? perdido.nome.toLowerCase() : '',
          encontrado.numero_limpo,
          perdido.numero ? perdido.numero.toLowerCase().replace(/[^a-z0-9]/gi, '') : ''
        ]
      );

      const score = scoreResult.rows[0]?.score || 0;

      if (score >= 0.55) {
        const tipoMatch = score >= 0.85 ? 'exato' : score >= 0.70 ? 'alto' : 'medio';

        // Criar match (evitar duplicados)
        const criado = await db.query(
          `INSERT INTO matches (documento_encontrado_id, documento_perdido_id, score, tipo_match)
           VALUES ($1, $2, $3, $4)
           ON CONFLICT (documento_encontrado_id, documento_perdido_id)
             WHERE documento_perdido_id IS NOT NULL
           DO NOTHING
           RETURNING id`,
          [documentoEncontradoId, perdido.id, score, tipoMatch]
        );

        // Só notifica se o match é novo (evita SMS repetidos)
        if (criado.rows.length > 0) {
          try {
            await notificarMatch({
              matchId: criado.rows[0].id,
              perdidoId: perdido.id,
              destino: perdido.contacto,
              autorizaSms: perdido.autoriza_sms
            });
          } catch (e) {
            console.error('Erro ao notificar:', e.message);
          }
        }
      }
    }
  } catch (err) {
    console.error('Erro ao criar matches:', err.message);
  }
}

module.exports = router;
