const express = require('express');
const router = express.Router();
const db = require('../db');
const { validateDocumento, cleanPhone } = require('../middleware/validate');

/**
 * POST /perdidos
 * Registar um pedido de notificação (quando não encontra correspondência)
 */
router.post('/', async (req, res) => {
  try {
    const {
      tipo,
      numero,
      nome,
      data_nascimento,
      contacto,
      autoriza_sms = true,
      autoriza_whatsapp = true
    } = req.body;

    // Validação
    const errors = validateDocumento({
      tipo,
      nome,
      contacto
    });

    if (errors.length > 0) {
      return res.status(400).json({
        success: false,
        errors
      });
    }

    const contactoLimpo = cleanPhone(contacto);

    // Verificar se já existe um registo recente com o mesmo contacto + tipo + nome
    const existente = await db.query(
      `SELECT id FROM documentos_perdidos
       WHERE contacto = $1
         AND tipo = $2
         AND nome_normalizado = lower(unaccent($3))
         AND status = 'à_espera'
         AND created_at > NOW() - INTERVAL '30 days'
       LIMIT 1`,
      [contactoLimpo, tipo, nome.trim()]
    );

    if (existente.rows.length > 0) {
      return res.status(200).json({
        success: true,
        message: 'Já temos o seu pedido de notificação registado. Avisaremos quando aparecer uma possível correspondência.',
        data: { id: existente.rows[0].id }
      });
    }

    const result = await db.query(
      `INSERT INTO documentos_perdidos
        (tipo, numero, nome, data_nascimento, contacto, autoriza_sms, autoriza_whatsapp)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING id, tipo, nome, contacto, status, created_at`,
      [
        tipo,
        numero ? numero.trim() : null,
        nome.trim(),
        data_nascimento || null,
        contactoLimpo,
        autoriza_sms,
        autoriza_whatsapp
      ]
    );

    const pedido = result.rows[0];

    res.status(201).json({
      success: true,
      message: 'Pedido de notificação registado com sucesso. Avisaremos por SMS/WhatsApp se aparecer uma possível correspondência.',
      data: {
        id: pedido.id,
        tipo: pedido.tipo,
        nome: pedido.nome,
        status: pedido.status,
        created_at: pedido.created_at
      }
    });

  } catch (error) {
    console.error('Erro ao registar pedido de notificação:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno ao registar o pedido'
    });
  }
});

module.exports = router;
