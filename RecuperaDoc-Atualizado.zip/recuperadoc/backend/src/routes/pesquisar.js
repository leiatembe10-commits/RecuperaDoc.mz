const express = require('express');
const router = express.Router();
const db = require('../db');
const { maskNumero, maskNome } = require('../utils/mask');

/**
 * GET /pesquisar
 * Procurar possíveis correspondências
 * Query params: tipo, numero, nome, data_nascimento (opcional)
 */
router.get('/', async (req, res) => {
  try {
    const { tipo, numero, nome, data_nascimento } = req.query;

    if (!tipo || !['bi', 'carta', 'passaporte', 'outro'].includes(tipo)) {
      return res.status(400).json({
        success: false,
        message: 'Tipo de documento é obrigatório e deve ser: bi, carta, passaporte ou outro'
      });
    }

    if (!nome || nome.trim().length < 3) {
      return res.status(400).json({
        success: false,
        message: 'Nome é obrigatório e deve ter pelo menos 3 caracteres'
      });
    }

    // Usar a função de matching já criada no schema
    const result = await db.query(
      `SELECT * FROM procurar_correspondencias($1, $2, $3, $4)`,
      [
        tipo,
        numero || null,
        nome.trim(),
        data_nascimento || null
      ]
    );

    const brutas = result.rows;

    if (brutas.length === 0) {
      return res.json({
        success: true,
        message: 'Nenhuma possível correspondência encontrada neste momento.',
        data: [],
        total: 0
      });
    }

    // Cada pesquisa recebe o seu próprio match (ID único), para que o ID
    // funcione como "bilhete" privado de quem pesquisou.
    const correspondencias = [];
    for (const row of brutas) {
      const m = await db.query(
        `INSERT INTO matches (documento_encontrado_id, score, tipo_match)
         VALUES ($1, $2, $3)
         RETURNING id`,
        [row.id, row.score, row.tipo_match]
      );
      correspondencias.push({
        match_id: m.rows[0].id,
        tipo: row.tipo,
        numero: maskNumero(row.numero),
        nome: maskNome(row.nome),
        cidade: row.cidade,
        score: parseFloat(row.score),
        tipo_match: row.tipo_match
        // NUNCA enviamos o contacto do finder nem o número completo aqui
      });
    }

    res.json({
      success: true,
      message: correspondencias.length === 1
        ? 'Encontrámos uma possível correspondência.'
        : `Encontrámos ${correspondencias.length} possíveis correspondências.`,
      data: correspondencias,
      total: correspondencias.length
    });

  } catch (error) {
    console.error('Erro na pesquisa:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno na pesquisa'
    });
  }
});

module.exports = router;
