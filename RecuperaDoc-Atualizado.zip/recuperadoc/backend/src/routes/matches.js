const express = require('express');
const router = express.Router();
const db = require('../db');
const { adminAuth } = require('../utils/auth');
const { maskNumero, maskNome, isUuid, normalizarCodigo } = require('../utils/mask');
const { isValidPhone, cleanPhone } = require('../middleware/validate');

const MAX_TENTATIVAS = 5;

function idInvalido(res) {
  return res.status(400).json({ success: false, message: 'ID inválido' });
}

/**
 * PASSO 1 do pagamento: POST /matches/:id/iniciar-pagamento
 * A pessoa diz para que serviço vai pagar e DE QUE NÚMERO vai transferir.
 * O número fica registado antes do pagamento (quem confirma compara depois).
 */
router.post('/:id/iniciar-pagamento', async (req, res) => {
  try {
    const { id } = req.params;
    if (!isUuid(id)) return idInvalido(res);

    const { metodo, numero_pagador } = req.body || {};
    if (!metodo || !['mpesa', 'emola'].includes(metodo)) {
      return res.status(400).json({ success: false, message: 'Escolha M-Pesa ou e-Mola.' });
    }
    if (!isValidPhone(numero_pagador)) {
      return res.status(400).json({
        success: false,
        message: 'Número inválido. Use um número moçambicano (ex: 84 123 4567).'
      });
    }
    const numero = cleanPhone(numero_pagador);

    const result = await db.query(
      `UPDATE matches
       SET pagamento_metodo = $1, pagamento_numero = $2
       WHERE id = $3 AND contacto_liberado = false AND pagamento_declarado = false
       RETURNING id`,
      [metodo, numero, id]
    );

    if (result.rows.length === 0) {
      const existe = await db.query('SELECT 1 FROM matches WHERE id = $1', [id]);
      if (existe.rows.length === 0) {
        return res.status(404).json({ success: false, message: 'Match não encontrado' });
      }
      return res.status(409).json({
        success: false,
        message: 'O pagamento deste pedido já foi declarado ou o contacto já foi liberado.'
      });
    }

    res.json({
      success: true,
      data: { valor: 45, metodo, numero_pagador: numero }
    });
  } catch (error) {
    console.error('Erro ao iniciar pagamento:', error);
    res.status(500).json({ success: false, message: 'Erro interno' });
  }
});

/**
 * PASSO 2 do pagamento: POST /matches/:id/pagar
 * Depois de transferir, a pessoa indica o código da transação.
 * A confirmação final é sempre manual (admin compara com a mensagem que recebeu).
 */
router.post('/:id/pagar', async (req, res) => {
  try {
    const { id } = req.params;
    if (!isUuid(id)) return idInvalido(res);

    const codigo = normalizarCodigo((req.body || {}).codigo_transacao);
    if (!codigo) {
      return res.status(400).json({
        success: false,
        message: 'Código da transação inválido. Copie-o da mensagem de confirmação (6 a 30 letras/números).'
      });
    }

    // Conta a tentativa e só deixa avançar se o pedido estiver no estado certo
    const tentativa = await db.query(
      `UPDATE matches
       SET pagamento_tentativas = pagamento_tentativas + 1
       WHERE id = $1
         AND contacto_liberado = false
         AND pagamento_declarado = false
         AND pagamento_numero IS NOT NULL
         AND pagamento_tentativas < $2
       RETURNING id`,
      [id, MAX_TENTATIVAS]
    );

    if (tentativa.rows.length === 0) {
      const m = await db.query(
        `SELECT contacto_liberado, pagamento_declarado, pagamento_numero, pagamento_tentativas
         FROM matches WHERE id = $1`,
        [id]
      );
      if (m.rows.length === 0) {
        return res.status(404).json({ success: false, message: 'Match não encontrado' });
      }
      const r = m.rows[0];
      if (r.contacto_liberado || r.pagamento_declarado) {
        return res.status(409).json({ success: false, message: 'O pagamento deste pedido já foi registado.' });
      }
      if (!r.pagamento_numero) {
        return res.status(400).json({ success: false, message: 'Indique primeiro o número de onde vai transferir.' });
      }
      return res.status(429).json({
        success: false,
        message: 'Demasiadas tentativas. Contacte o suporte do RecuperaDoc.'
      });
    }

    try {
      await db.query(
        `UPDATE matches
         SET pagamento_codigo = $1,
             pagamento_declarado = true,
             pagamento_declarado_em = NOW(),
             pagamento_status = 'pendente',
             pagamento_valor = 45.00
         WHERE id = $2`,
        [codigo, id]
      );
    } catch (err) {
      if (err.code === '23505') {   // violação do índice único: código já usado
        return res.status(409).json({
          success: false,
          message: 'Este código de transação já foi usado noutro pedido.'
        });
      }
      throw err;
    }

    res.json({
      success: true,
      message: 'Pagamento registado. Aguarde a confirmação.'
    });
  } catch (error) {
    console.error('Erro ao registar pagamento:', error);
    res.status(500).json({ success: false, message: 'Erro interno' });
  }
});

/**
 * POST /matches/:id/desbloquear  (ADMIN)
 * Liberta o contacto depois de o admin confirmar o pagamento.
 */
router.post('/:id/desbloquear', adminAuth, async (req, res) => {
  try {
    const { id } = req.params;
    if (!isUuid(id)) return idInvalido(res);

    const matchResult = await db.query(
      `SELECT m.id, m.pagamento_declarado, e.contacto_finder, e.nome_finder, e.cidade, e.tipo, e.numero, e.nome
       FROM matches m
       JOIN documentos_encontrados e ON e.id = m.documento_encontrado_id
       WHERE m.id = $1`,
      [id]
    );

    if (matchResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Match não encontrado' });
    }

    const match = matchResult.rows[0];

    if (!match.pagamento_declarado) {
      return res.status(409).json({
        success: false,
        message: 'Este pedido ainda não tem pagamento declarado (número e código).'
      });
    }

    let quem = null;
    try {
      quem = decodeURIComponent(String(req.headers['x-admin-nome'] || '')).trim().slice(0, 40) || null;
    } catch (e) { quem = null; }

    await db.query(
      `UPDATE matches
       SET pagamento_status = 'pago',
           contacto_liberado = true,
           pago_em = COALESCE(pago_em, NOW()),
           liberado_em = COALESCE(liberado_em, NOW()),
           liberado_por = COALESCE(liberado_por, $2)
       WHERE id = $1`,
      [id, quem]
    );

    console.log(`[admin] contacto desbloqueado: match ${id} por ${quem || 'desconhecido'} em ${new Date().toISOString()}`);

    res.json({
      success: true,
      message: 'Contacto desbloqueado com sucesso',
      data: {
        match_id: match.id,
        contacto_finder: match.contacto_finder,
        nome_finder: match.nome_finder,
        cidade: match.cidade,
        tipo_documento: match.tipo,
        numero_documento: match.numero,
        nome_documento: match.nome
      }
    });
  } catch (error) {
    console.error('Erro ao desbloquear contacto:', error);
    res.status(500).json({ success: false, message: 'Erro interno' });
  }
});

/**
 * GET /matches/:id
 * Estado de um match. O contacto só aparece depois de liberado.
 * O número e o nome do documento saem sempre mascarados.
 */
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    if (!isUuid(id)) return idInvalido(res);

    const result = await db.query(
      `SELECT
         m.id, m.score, m.tipo_match, m.pagamento_status, m.pagamento_declarado,
         m.pagamento_metodo, m.pagamento_numero, m.contacto_liberado,
         CASE WHEN m.contacto_liberado THEN e.contacto_finder END AS contacto_finder,
         CASE WHEN m.contacto_liberado THEN e.nome_finder END AS nome_finder,
         CASE WHEN m.contacto_liberado THEN e.observacoes END AS observacoes,
         e.cidade, e.tipo, e.numero, e.nome
       FROM matches m
       JOIN documentos_encontrados e ON e.id = m.documento_encontrado_id
       WHERE m.id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Match não encontrado' });
    }

    const r = result.rows[0];
    res.json({
      success: true,
      data: {
        id: r.id,
        score: r.score,
        tipo_match: r.tipo_match,
        pagamento_status: r.pagamento_status,
        pagamento_declarado: r.pagamento_declarado,
        pagamento_metodo: r.pagamento_metodo,
        numero_registado: !!r.pagamento_numero,
        numero_final: r.pagamento_numero ? r.pagamento_numero.slice(-3) : null,
        contacto_liberado: r.contacto_liberado,
        contacto_finder: r.contacto_finder,
        nome_finder: r.nome_finder,
        observacoes: r.observacoes,
        cidade: r.cidade,
        tipo: r.tipo,
        numero: maskNumero(r.numero),
        nome: maskNome(r.nome)
      }
    });
  } catch (error) {
    console.error('Erro ao buscar match:', error);
    res.status(500).json({ success: false, message: 'Erro interno' });
  }
});

module.exports = router;
