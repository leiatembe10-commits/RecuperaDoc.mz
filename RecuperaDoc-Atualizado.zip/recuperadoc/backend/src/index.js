require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const encontradosRouter = require('./routes/encontrados');
const perdidosRouter = require('./routes/perdidos');
const pesquisarRouter = require('./routes/pesquisar');
const matchesRouter = require('./routes/matches');
const { adminAuth } = require('./utils/auth');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

// Atrás de proxy (Railway, Nginx...) o IP real vem no header; necessário para o rate limit
if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY) || 1);

// Segurança básica
app.use(helmet());
app.use(express.json({ limit: '1mb' }));

// CORS
// Sem CORS_ORIGIN definido, só aceita localhost (desenvolvimento). Em produção define o teu domínio.
const allowedOrigins = (process.env.CORS_ORIGIN
  ? process.env.CORS_ORIGIN.split(',').map(o => o.trim())
  : ['http://localhost:5500', 'http://127.0.0.1:5500', 'http://localhost:3000']);
app.use(cors({
  origin: function (origin, callback) {
    if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Não permitido pelo CORS'));
    }
  }
}));

// Rate limiting (anti-spam)
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 300, // máximo 300 pedidos por IP (inclui a verificação periódica do pagamento)
  message: {
    success: false,
    message: 'Demasiados pedidos. Tente novamente dentro de alguns minutos.'
  }
});
app.use(limiter);

// Rate limit mais apertado para pesquisa
const searchLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minuto
  max: 10,
  message: {
    success: false,
    message: 'Demasiadas pesquisas. Aguarde um minuto.'
  }
});

// Rotas
app.get('/', (req, res) => {
  res.json({
    name: 'RecuperaDoc API',
    version: '1.0.0',
    status: 'online',
    endpoints: {
      'POST /encontrados': 'Registar documento encontrado',
      'POST /perdidos': 'Registar pedido de notificação',
      'GET /pesquisar': 'Pesquisar correspondências',
      'POST /matches/:id/pagar': 'Registar pagamento',
      'POST /matches/:id/desbloquear': 'Desbloquear contacto (admin)',
      'GET /matches/:id': 'Ver estado do match'
    }
  });
});

app.use('/encontrados', encontradosRouter);
app.use('/perdidos', perdidosRouter);
app.use('/pesquisar', searchLimiter, pesquisarRouter);
app.use('/matches', matchesRouter);

// ========== ENDPOINTS DE ADMIN (protegidos por chave) ==========
const adminLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  message: { success: false, message: 'Demasiados pedidos ao admin.' }
});
app.use('/admin', adminLimiter, adminAuth);

app.get('/admin/encontrados', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT id, tipo, numero, nome, cidade, contacto_finder, status, created_at
       FROM documentos_encontrados
       ORDER BY created_at DESC LIMIT 50`
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Erro interno' });
  }
});

app.get('/admin/perdidos', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT id, tipo, numero, nome, contacto, status, created_at
       FROM documentos_perdidos
       ORDER BY created_at DESC LIMIT 50`
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Erro interno' });
  }
});

app.get('/admin/matches', async (req, res) => {
  try {
    // Primeiro os que têm pagamento declarado e ainda não foram liberados
    const result = await db.query(
      `SELECT m.id, m.score, m.tipo_match, m.pagamento_status, m.pagamento_declarado,
              m.contacto_liberado, m.pagamento_metodo, m.pagamento_numero, m.pagamento_codigo,
              m.pagamento_declarado_em, m.liberado_por, m.created_at,
              e.nome AS nome_doc, e.tipo, e.cidade, e.contacto_finder
       FROM matches m
       JOIN documentos_encontrados e ON e.id = m.documento_encontrado_id
       ORDER BY (m.pagamento_declarado AND NOT m.contacto_liberado) DESC, m.created_at DESC
       LIMIT 50`
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Erro interno' });
  }
});

app.get('/admin/notificacoes', async (req, res) => {
  try {
    const result = await db.query(
      `SELECT id, canal, destino, status, erro, created_at, enviado_em
       FROM notificacoes ORDER BY created_at DESC LIMIT 50`
    );
    res.json({ success: true, data: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Erro interno' });
  }
});

// 404
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Endpoint não encontrado'
  });
});


// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    message: 'Erro interno do servidor'
  });
});

app.listen(PORT, () => {
  console.log(`🚀 RecuperaDoc API a correr na porta ${PORT}`);
  console.log(`📡 Ambiente: ${process.env.NODE_ENV || 'development'}`);
});
