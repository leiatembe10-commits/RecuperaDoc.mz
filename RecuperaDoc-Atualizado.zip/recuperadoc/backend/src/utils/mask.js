// Mascara dados sensíveis antes de os mostrar a quem pesquisa.
// O objetivo é permitir confirmar "é o meu" sem expor o documento completo.

function maskNumero(numero) {
  if (!numero) return null;
  const s = String(numero).trim();
  if (s.length <= 4) return '•'.repeat(s.length);
  const visiveis = s.length >= 8 ? 2 : 1;
  return s.slice(0, visiveis) + '•'.repeat(s.length - visiveis * 2) + s.slice(-visiveis);
}

// Mostra o primeiro nome e só a inicial dos restantes: "João M••• S•••"
function maskNome(nome) {
  const partes = String(nome || '').trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0) return '';
  return partes
    .map((p, i) => (i === 0 ? p : p[0].toUpperCase() + '•••'))
    .join(' ');
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function isUuid(v) {
  return typeof v === 'string' && UUID_RE.test(v);
}

// Código de transação (M-Pesa / e-Mola): sem espaços, maiúsculas, 6 a 30 caracteres
function normalizarCodigo(v) {
  if (typeof v !== 'string') return null;
  const c = v.trim().toUpperCase().replace(/[\s\-]/g, '');
  return /^[A-Z0-9.]{6,30}$/.test(c) ? c : null;
}

module.exports = { maskNumero, maskNome, isUuid, normalizarCodigo };
