const crypto = require('crypto');

// Middleware de autenticação do admin (chave no header x-admin-secret).
// Compara em tempo constante e nunca aceita a chave no corpo do pedido.
function adminAuth(req, res, next) {
  const secret = process.env.ADMIN_SECRET || '';
  const provided = String(req.headers['x-admin-secret'] || '');
  const a = crypto.createHash('sha256').update(provided).digest();
  const b = crypto.createHash('sha256').update(secret).digest();

  if (!secret || !crypto.timingSafeEqual(a, b)) {
    return res.status(403).json({ success: false, message: 'Não autorizado' });
  }
  next();
}

module.exports = { adminAuth };
