// Validação básica de dados

function isValidPhone(phone) {
  if (!phone) return false;
  // Aceita formatos moçambicanos: +25884..., 84..., 25884...
  const cleaned = phone.replace(/[\s\-\(\)]/g, '');
  return /^(\+?258)?8[2-7]\d{7}$/.test(cleaned);
}

function cleanPhone(phone) {
  if (!phone) return null;
  let cleaned = phone.replace(/[\s\-\(\)]/g, '');
  if (cleaned.startsWith('258')) cleaned = '+' + cleaned;
  if (!cleaned.startsWith('+') && cleaned.startsWith('8')) cleaned = '+258' + cleaned;
  return cleaned;
}

function validateDocumento(body) {
  const errors = [];

  if (!body.tipo || !['bi', 'carta', 'passaporte', 'outro'].includes(body.tipo)) {
    errors.push('Tipo de documento inválido. Use: bi, carta, passaporte ou outro');
  }

  if (!body.nome || body.nome.trim().length < 3) {
    errors.push('Nome é obrigatório e deve ter pelo menos 3 caracteres');
  }

  if (!body.contacto || !isValidPhone(body.contacto)) {
    errors.push('Contacto inválido. Use um número moçambicano válido (ex: 84 123 4567)');
  }

  return errors;
}

module.exports = {
  isValidPhone,
  cleanPhone,
  validateDocumento
};
